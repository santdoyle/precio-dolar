<?php

class preciosmodel{

	private $nombre;
	private $compra;
	private $venta;
	private $fecha;
	private $variacion;

	public function getNombre()
	{
	    return $this->nombre;
	}
	public function setNombre($nombre)
	{
	    $this->nombre = $nombre;
	    return $this;
	}

	public function getCompra()
	{
	    return $this->compra;
	}
	public function setCompra($compra)
	{
	    $this->compra = $compra;
	    return $this;
	}

	public function getVenta()
	{
	    return $this->venta;
	}
	public function setVenta($venta)
	{
	    $this->venta = $venta;
	    return $this;
	}

	public function getFecha()
	{
	    return $this->fecha;
	}
	public function setFecha($fecha)
	{
	    $this->fecha = $fecha;
	    return $this;
	}

	public function getVariacion()
	{
	    return $this->variacion;
	}
	public function setVariacion($variacion)
	{
	    $this->variacion = $variacion;
	    return $this;
	}


	public function verPrecio(){

		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://www.dolarsi.com/api/api.php?type=valoresprincipales",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_SSL_VERIFYHOST => 0,
      	  CURLOPT_SSL_VERIFYPEER => 0,
		));

		$response = curl_exec($curl);

		curl_close($curl);
		
		return $response;

	}

}