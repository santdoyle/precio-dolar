
    <footer class="text-muted bg-light">
      <div class="container">
        <p class="float-right">
          <a href="#">Back to top</a>
        </p>
        <p>Comprardolareshoy.com.ar &copy; 2020!</p>
        <p><a href="<?=base_url?>">Contacto</a> - <a href="<?=base_url?>">Privacidad</a> - <a href="<?=base_url?>">Publicidad</a> - <a href="<?=base_url?>">Blog</a></p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
    <!-- <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>-->
    <script src="<?=base_url?>assets/js/jquery-3.5.1.min.js"></script>
    <!-- <script src="../../assets/js/vendor/popper.min.js"></script>-->
    <script src="<?=base_url?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- <script src="../../assets/js/vendor/holder.min.js"></script>-->
    <script src="<?=base_url?>assets/js/functions.js"></script>
    <script type="text/javascript" src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
    <script type="text/javascript" src="<?=base_url?>assets/js/datatables.min.js"></script>
  </body>
</html>