<?php

DEFINE('controller_default', 'home');
DEFINE('action_default', 'ver');
DEFINE('base_url', 'http://localhost:8080/dolar/');